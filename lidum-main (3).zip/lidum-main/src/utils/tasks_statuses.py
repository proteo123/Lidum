MINTED = "minted"
FAILED = "failed"
PENDING = "pending"
NEW = "new"

SUCCESS = "success"
CRUSHED = "crushed"
CANCELED = "canceled"
