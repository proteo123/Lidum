import os
import base64
from typing import Any

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher
from cryptography.hazmat.primitives.ciphers import modes
from cryptography.hazmat.primitives.ciphers import algorithms

from ..config import ENCRYPTION_KEY


def encrypt(msg: Any):
    iv = os.urandom(16)
    data = f"{msg}".encode()

    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()

    cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv))
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()

    final_data = iv + encrypted_data

    return base64.urlsafe_b64encode(final_data).decode()


def decrypt(msg: str):
    encrypted_data = base64.urlsafe_b64decode(msg.encode())
    iv = encrypted_data[: 16]
    encrypted_data = encrypted_data[16 :]

    cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv))
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(encrypted_data) + decryptor.finalize()

    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()

    return data.decode()


def encrypt_event_link(event_id: int, link_number: int):
    iv = os.urandom(16)
    data = f"{event_id}:{link_number}".encode()

    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()

    cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv))
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()

    final_data = iv + encrypted_data

    return base64.urlsafe_b64encode(final_data).decode()


def decrypt_event_link(encrypted_link: str):
    encrypted_data = base64.urlsafe_b64decode(encrypted_link.encode())
    iv = encrypted_data[: 16]
    encrypted_data = encrypted_data[16 :]

    cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv))
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(encrypted_data) + decryptor.finalize()

    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()

    event_id, link_number = data.decode().split(':')

    return int(event_id), int(link_number)
