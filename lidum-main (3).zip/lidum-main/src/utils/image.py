import base64
from io import BytesIO
from os import makedirs
from os.path import split
from pathlib import Path

from PIL import Image


def decode_base64_image(image: str):
    """Декодирует изображение, находящее в base64 строке."""

    extension = image.split(";")[0].split("/")[1]

    image = image.split(",")[1]
    image = base64.b64decode(image)

    return image, extension


def save_base64_image(image: bytes, image_path: str):
    """Сохраняет в директории коллекции полученное изображение."""

    makedirs(split(image_path)[0], exist_ok=True)

    path = Path(image_path).with_suffix('.png')

    image = Image.open(BytesIO(image))
    image.save(path, 'PNG')
